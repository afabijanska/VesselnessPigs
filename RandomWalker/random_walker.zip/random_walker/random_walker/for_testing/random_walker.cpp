//
// MATLAB Compiler: 6.1 (R2015b)
// Date: Sun Mar 20 21:10:19 2016
// Arguments: "-B" "macro_default" "-W" "cpplib:random_walker" "-T" "link:lib"
// "-d"
// "C:\Users\Ania\Documents\MATLAB\random_walker\random_walker\for_testing"
// "-v" "C:\Users\Ania\Documents\MATLAB\random_walker\adjacency.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\dirichletboundary.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\laplacian.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\lattice.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\makeweights.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\normalize.m"
// "C:\Users\Ania\Documents\MATLAB\random_walker\random_walker.m" 
//

#include <stdio.h>
#define EXPORTING_random_walker 1
#include "random_walker.h"

static HMCRINSTANCE _mcr_inst = NULL;


#if defined( _MSC_VER) || defined(__BORLANDC__) || defined(__WATCOMC__) || defined(__LCC__)
#ifdef __LCC__
#undef EXTERN_C
#endif
#include <windows.h>

static char path_to_dll[_MAX_PATH];

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, void *pv)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        if (GetModuleFileName(hInstance, path_to_dll, _MAX_PATH) == 0)
            return FALSE;
    }
    else if (dwReason == DLL_PROCESS_DETACH)
    {
    }
    return TRUE;
}
#endif
#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_random_walker_C_API
#define LIB_random_walker_C_API /* No special import/export declaration */
#endif

LIB_random_walker_C_API 
bool MW_CALL_CONV random_walkerInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
  if (!GetModuleFileName(GetModuleHandle("random_walker"), path_to_dll, _MAX_PATH))
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream(path_to_dll);
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_random_walker_C_API 
bool MW_CALL_CONV random_walkerInitialize(void)
{
  return random_walkerInitializeWithHandlers(mclDefaultErrorHandler, 
                                             mclDefaultPrintHandler);
}

LIB_random_walker_C_API 
void MW_CALL_CONV random_walkerTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_random_walker_C_API 
void MW_CALL_CONV random_walkerPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(&stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_random_walker_C_API 
bool MW_CALL_CONV mlxAdjacency(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "adjacency", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxDirichletboundary(int nlhs, mxArray *plhs[], int nrhs, mxArray 
                                       *prhs[])
{
  return mclFeval(_mcr_inst, "dirichletboundary", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxLaplacian(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "laplacian", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxLattice(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "lattice", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxMakeweights(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "makeweights", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxNormalize(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "normalize", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_C_API 
bool MW_CALL_CONV mlxRandom_walker(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "random_walker", nlhs, plhs, nrhs, prhs);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV adjacency(int nargout, mwArray& W, const mwArray& edges, const mwArray& 
                            weights, const mwArray& N)
{
  mclcppMlfFeval(_mcr_inst, "adjacency", nargout, 1, 3, &W, &edges, &weights, &N);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV dirichletboundary(int nargout, mwArray& newVals, const mwArray& L, 
                                    const mwArray& index, const mwArray& vals)
{
  mclcppMlfFeval(_mcr_inst, "dirichletboundary", nargout, 1, 3, &newVals, &L, &index, &vals);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV laplacian(int nargout, mwArray& L, const mwArray& edges, const mwArray& 
                            weights, const mwArray& N)
{
  mclcppMlfFeval(_mcr_inst, "laplacian", nargout, 1, 3, &L, &edges, &weights, &N);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV lattice(int nargout, mwArray& points, mwArray& edges, const mwArray& X, 
                          const mwArray& Y, const mwArray& connect)
{
  mclcppMlfFeval(_mcr_inst, "lattice", nargout, 2, 3, &points, &edges, &X, &Y, &connect);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV makeweights(int nargout, mwArray& weights, const mwArray& edges, const 
                              mwArray& vals, const mwArray& valScale, const mwArray& 
                              points, const mwArray& geomScale, const mwArray& EPSILON)
{
  mclcppMlfFeval(_mcr_inst, "makeweights", nargout, 1, 6, &weights, &edges, &vals, &valScale, &points, &geomScale, &EPSILON);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV normalize(int nargout, mwArray& normVals, const mwArray& newVals, const 
                            mwArray& oldVals)
{
  mclcppMlfFeval(_mcr_inst, "normalize", nargout, 1, 2, &normVals, &newVals, &oldVals);
}

LIB_random_walker_CPP_API 
void MW_CALL_CONV random_walker(int nargout, mwArray& mask, mwArray& probabilities, const 
                                mwArray& img, const mwArray& seeds, const mwArray& 
                                labels, const mwArray& beta)
{
  mclcppMlfFeval(_mcr_inst, "random_walker", nargout, 2, 4, &mask, &probabilities, &img, &seeds, &labels, &beta);
}

